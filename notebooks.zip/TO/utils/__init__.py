from .set_seed import set_seed
from .gen_data import get_data_fluid
from .visualize import plot_loss_history, plot_predictions_and_residuals,plot_density_and_velocity_fields