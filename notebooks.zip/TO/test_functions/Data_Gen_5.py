# -*- coding: utf-8 -*-
"""
This module contains functions to generate data for multi-fidelity problems.
Inputs for each function are, in order, n_train, n_val, and n_test.
Data is sampled via sobol sequence.
Data generation functions should scale both inputs and outputs to [0,1] via
min-max normalization for consistency, and should return the min and max used
for both the input and output so that data can be un-scaled. If other
normalization/scaling is desired by the user, this can be achieved by un-
scaling the data and then applying the appropriate normalization as part of
data preprocessing (e.g. Z-score normalization).

Required libraries:
    numpy
    pyDOE
    tensorflow

Contains the following functions:
    SinWave_v1_MX
    Analytic_1_MF
    Borehole_MF
    MF_Data_Gen

Created on Thu May 12 17:00:06 2022

@author: Jonathan Tammer Eweis-LaBolle
"""

# Import statements
import numpy as np
from pyDOE import lhs
import tensorflow as tf
k = tf.keras
km = k.models
kl = k.layers
ko = k.optimizers
kcb = k.callbacks
kr = k.regularizers


# Function definitions

#### Multi Fidelity Data Generation Functions

def Analytic_1_MF(n_train, n_val, n_test, var = (0, 0, 0, 0)):
    """
    Generates data for a simple 1-D multi-fidelity problem which contains four
    datasets y_h, y_l1, y_l2, and y_l3.
    The problem can be found in section 3.2.1 of Data Fusion with Latent Map
    Gaussian Processes (Eweis-LaBolle, 2022).
    Input and output dimensions are 1 and 1 respectively, with an additional
    categorical input feature added to denote data source.
    Data is scaled to the range [0, 1] based on mins and maxs of each data
    source. The "SS" refers to the fact that each source is separately scaled.
    Use the mins and maxs returned by this function to un-scale the data if 
    desired.
    
    Inputs:
        n_train: A tuple of length 4 that determines the number of training
            samples for (y_h, y_l1, y_l2, y_l3)
        n_val: A tuple of length 4 that determines the number of validation
            samples for (y_h, y_l1, y_l2, y_l3)
        n_test: A tuple of length 4 that determines the number of test
            samples for (y_h, y_l1, y_l2, y_l3)
        var: A tuple of length 4 that determines the noise variance to be
            applied to the outputs for (y_h, y_l1, y_l2, y_l3). Note that
            noise is applied to the test data. Noise is applied before scaling.
            Recommended range: [0, .005]
    
    Outputs:
        dx: The total input dimensionality including souce idx. dx = int(2)
        dnum: The numeric input dimensionality. dnum = int(1)
        dy: The output dimensionality. dy = int(1)
        dt: A touple whose length denotes the number of all categorical variables and
            whose entries denote the number of levels for each. dt = (4,)
        dsource: A touple whose length denotes the number of the categorical varaible
            that denotes data source and whose entries denote the number of levels for each. dt = (4,)
        num_idx: An np array which lists the indices of the input that correspond
            to numerical variables. num_idx = (0,)
        source_idx: An np array which lists the indices of the input that correspond
            to categorical variables. source_idx = (1,)
        MIN: The minimum of the sample range for the input. 
            MIN = (-2,)
        MAX: The maximum of the sample range for the input.
            MAX = (3,)
        min_y: The minimum of the sample range for the output for each source. The
            four rows refer to [yh, yl1, yl2, yl3] respectively.
        max_y: The maximum of the sample range for the output for each source. The
            four rows refer to [yh, yl1, yl2, yl3] respectively.
        x_train: The training inputs.
        y_train: The training outputs.
        x_val: The validation inputs.
        y_val: The validation outputs.
        x_test: The testing inputs.
        y_test: The testing outputs.
    """
    
    # Set parameters
    dx = 2
    dnum = 1
    dy = 1
    # dt is a list whose indices correspond to the categorical variable
    # and whose entries correspond to the number of levels for that variable
    dt = (4,)
    dsource = (4,)
    num_idx = np.array([0])
    source_idx = np.array([1])
    MIN = (-2,)
    MAX = (3,)
    RANGE = [MAX[i] - MIN[i] for i in range(dnum)]
    # Define functions    
    y1 = lambda x: 1. / (.1*x[:]**3 + x[:]**2 + x[:] +1)
    y2 = lambda x: 1. / (.2*x[:]**3 + x[:]**2 + x[:] +1)
    y3 = lambda x: 1. / (x[:]**2 + x[:] +1)
    y4 = lambda x: 1. / (x[:]**2 +1)
    y_list = [y1, y2, y3, y4]
    y = lambda x, t: y_list[t](x)
    # Preallocate data arrays and indices
    # First, get the total number of input points for each set
    train_tot = sum(n_train)
    val_tot = sum(n_val)
    test_tot = sum(n_test)
    x_train = np.empty([train_tot, dx])
    x_val = np.empty([val_tot, dx])
    x_test = np.empty([test_tot, dx])
    y_train = np.empty([train_tot, dy])
    y_val = np.empty([val_tot, dy])
    y_test = np.empty([test_tot, dy])
    min_x = np.empty([dt[0], dnum]) # Set shape based on number of sources
    max_x = np.empty([dt[0], dnum]) # Set shape based on number of sources
    min_y = np.empty([dt[0], dy]) # Set shape based on number of sources
    max_y = np.empty([dt[0], dy]) # Set shape based on number of sources

    # Initialize the indices for training
    train_start = 0
    val_start = 0
    test_start = 0
    # Generate data
    for i in range(dt[0]):
        # Set end indices
        train_end = train_start + n_train[i]
        val_end = val_start + n_val[i]
        test_end = test_start + n_test[i]

        # Get data numbers
        n_train_temp = n_train[i]
        n_val_temp = n_val[i]
        n_test_temp = n_test[i]

        # Generate data
        x_train_temp = lhs(dnum, samples = n_train_temp) * RANGE + MIN
        y_train_temp = y(x_train_temp, i).reshape((n_train_temp, dy))

        x_val_temp = lhs(dnum, samples = n_val_temp) * RANGE + MIN
        y_val_temp = y(x_val_temp, i).reshape((n_val_temp, 1))

        x_test_temp = lhs(dnum, samples = n_test_temp) * RANGE + MIN
        y_test_temp = y(x_test_temp, i).reshape((n_test_temp, dy))

        # Add noise
        y_train_temp = y_train_temp + np.sqrt(var[i])*np.random.standard_normal(size=y_train_temp.shape)
        y_val_temp = y_val_temp + np.sqrt(var[i])*np.random.standard_normal(size=y_val_temp.shape)
        y_test_temp = y_test_temp + np.sqrt(var[i])*np.random.standard_normal(size=y_test_temp.shape)

        # Get the mins and maxs and store them
        min_x_temp = np.min(np.concatenate((x_train_temp[:, num_idx], x_val_temp[:, num_idx]), axis = 0), axis = 0)
        min_x[i, :] = min_x_temp
        max_x_temp = np.max(np.concatenate((x_train_temp[:, num_idx], x_val_temp[:, num_idx]), axis = 0), axis = 0)
        max_x[i, :] = max_x_temp

        min_y_temp = np.min(np.concatenate((y_train_temp, y_val_temp), axis = 0), axis = 0)
        min_y[i, :] = min_y_temp
        max_y_temp = np.max(np.concatenate((y_train_temp, y_val_temp), axis = 0), axis = 0)
        max_y[i, :] = max_y_temp

        # Store the data
        x_train[train_start : train_end, 0:dnum] = x_train_temp
        x_train[train_start : train_end, dnum:dnum+source_idx[0]] = i*np.ones((np.shape(x_train_temp)[0], 1))
        y_train[train_start : train_end, :] = y_train_temp

        x_val[val_start : val_end, 0:dnum] = x_val_temp
        x_val[val_start : val_end, dnum:dnum+source_idx[0]] = i*np.ones((np.shape(x_val_temp)[0], 1))
        y_val[val_start : val_end, :] = y_val_temp

        x_test[test_start : test_end, 0:dnum] = x_test_temp
        x_test[test_start : test_end, dnum:dnum+source_idx[0]] = i*np.ones((np.shape(x_test_temp)[0], 1))
        y_test[test_start : test_end, :] = y_test_temp

        # Update indices
        train_start = train_end
        val_start = val_end
        test_start = test_end

    return (dx, dnum, dsource, dt, dy, num_idx, source_idx, min_x, max_x, min_y, max_y, x_train, y_train, x_val, y_val, x_test, y_test)


def Borehole_MF(n_train, var = (0, 0, 0, 0,0)):
    # Set parameters
    dx = 9
    dnum = 8
    dy = 1
    # dt is a list whose indices correspond to the categorical variable
    # and whose entries correspond to the number of levels for that variable
    dt = (5,)
    dsource = (4,)
    num_idx = np.array(list(range(0, 8)))
    source_idx = np.array([8])
    MIN = (100, 990, 700, 100, .05, 10, 1000, 6000)
    MAX = (1000, 1110, 820, 10000, .15, 500, 2000, 12000)
    RANGE = [MAX[i] - MIN[i] for i in range(dnum)]
    # Define functions
    def y_h(x):
        Tu, Hu, Hl, r, rw, Tl, L, Kw = [x[:, i] for i in range(8)]
        Numer = 2*np.pi*Tu
        return (Numer*(Hu-Hl))/(np.log(r/rw)*(1+((2*L*Tu)/(np.log(r/rw)*(rw**2)*Kw))+(Tu/Tl)))
    def y_l1(x):
        Tu, Hu, Hl, r, rw, Tl, L, Kw = [x[:, i] for i in range(8)]
        Numer = 2*np.pi*Tu
        return (Numer*(Hu-.8*Hl))/(np.log(r/rw)*(1+((1*L*Tu)/(np.log(r/rw)*(rw**2)*Kw))+(Tu/Tl)))
    def y_l2(x):
        Tu, Hu, Hl, r, rw, Tl, L, Kw = [x[:, i] for i in range(8)]
        Numer = 2*np.pi*Tu
        return (Numer*(Hu-Hl))/(np.log(r/rw)*(1+((8*L*Tu)/(np.log(r/rw)*(rw**2)*Kw))+.75*(Tu/Tl)))

    def y_l3(x):
        Tu, Hu, Hl, r, rw, Tl, L, Kw = [x[:, i] for i in range(8)]
        Numer = 2*np.pi*Tu
        return (Numer*(1.09*Hu-Hl))/(np.log(4*r/rw)*(1+((3*L*Tu)/(np.log(r/rw)*(rw**2)*Kw))+(Tu/Tl)))


    def y_l4(x):
        Tu, Hu, Hl, r, rw, Tl, L, Kw = [x[:, i] for i in range(8)]
        Numer = 2*np.pi*Tu
        return (Numer*(1.05*Hu-Hl))/(np.log(2*r/rw)*(1+((3*L*Tu)/(np.log(r/rw)*(rw**2)*Kw))+(Tu/Tl)))

    

    y_list = [y_h, y_l1, y_l2, y_l3,y_l4]
    y = lambda x, t: y_list[t](x)
    # Preallocate data arrays and indices
    # First, get the total number of input points for each set
    train_tot = sum(n_train)
    x_train = np.empty([train_tot, dx])
    y_train = np.empty([train_tot, dy])
    # Initialize the indices for training
    train_start = 0
    # Generate data
    for i in range(dt[0]):
        # Set end indices
        train_end = train_start + n_train[i]
        n_train_temp = n_train[i]
        x_train_temp = lhs(dnum, samples = n_train_temp) * RANGE + MIN
        y_train_temp = y(x_train_temp, i).reshape((n_train_temp, dy))
        y_train_temp = y_train_temp + np.sqrt(var[i])*np.random.standard_normal(size=y_train_temp.shape)
        # Store the data
        x_train[train_start : train_end, 0:dnum] = x_train_temp
        x_train[train_start : train_end, dnum:dnum+source_idx[0]] = i*np.ones((np.shape(x_train_temp)[0], 1))
        y_train[train_start : train_end, :] = y_train_temp
        # Update indices
        train_start = train_end
#(dx, dnum, dsource, dt, dy, num_idx, source_idx, min_x, max_x, min_y, max_y, x_train, y_train, x_val, y_val, x_test, y_test)
    return x_train , y_train




def WingWeight_MF(n_train, n_val, n_test, var = (0, 0, 0, 0)):
    """
    Generates data for the multi-fidelity Wing Weight problem, which contains four
    datasets y_h, y_l1, y_l2, and y_l3.
    Input and output dimensions are 8 and 1 respectively, with an additional
    categorical input feature added to denote data source.
    Data is scaled to the range [0, 1] based on mins and maxs of each data
    source. The "SS" refers to the fact that each source is separately scaled.
    Use the mins and maxs returned by this function to un-scale the data if 
    desired.
    
    Inputs:
        n_train: A touple of length 4 that determines the number of training
            samples for (y_h, y_l1, y_l2, y_l3)
        n_val: A touple of length 4 that determines the number of validation
            samples for (y_h, y_l1, y_l2, y_l3)
        n_test: A touple of length 4 that determines the number of test
            samples for (y_h, y_l1, y_l2, y_l3)
        var: A tuple of length 4 that determines the noise variance to be
            applied to the outputs for (y_h, y_l1, y_l2, y_l3). Note that
            noise is applied to the test data. Noise is applied before scaling.
            Recommended range: [0, 50]
    
    Outputs:
        dx: The input dimensionality. dx = int(11)
        dy: The output dimensionality. dy = int(1)
        dt: A touple whose length denotes the number of categorical variables and
            whose entries denote the number of levels for each. dt = (4,)
        num_idx: An np array which lists the indices of the input that correspond
            to numerical variables. num_idx = (0, 1, 2, 3, 4, 5, 6, 7, 8, 9)
        source_idx: An np array which lists the indices of the input that correspond
            to categorical variables. source_idx = (8,)
        MIN: The minimum of the sample range for the input. 
            MIN = (100, 990, 700, 100, .05, 10, 1000, 6000)
        MAX: The maximum of the sample range for the input.
            MAX = (1000, 1110, 820, 10000, .15, 500, 2000, 12000)
        min_y: The minimum of the sample range for the output for each source. The
            four rows refer to [yh, yl1, yl2, yl3] respectively.
        max_y: The maximum of the sample range for the output for each source. The
            four rows refer to [yh, yl1, yl2, yl3] respectively.
        x_train: The training inputs.
        y_train: The training outputs.
        x_val: The validation inputs.
        y_val: The validation outputs.
        x_test: The testing inputs.
        y_test: The testing outputs.
    """
    
    # Set parameters
    dx = 11
    dnum = 10
    dy = 1
    # dt is a list whose indices correspond to the categorical variable
    # and whose entries correspond to the number of levels for that variable
    dt = (4,)
    dsource = (4,)
    num_idx = np.array(list(range(0, 10)))
    source_idx = np.array([10])
    MIN = (150, 220, 6, -10, 16, 0.5, 0.08, 2.5, 1700, 0.025)
    MAX = (200, 300, 10, 10, 45, 1, 0.18, 6, 2500, 0.08)
    RANGE = [MAX[i] - MIN[i] for i in range(dnum)]
    # Define functions
    def y_h(x):
        Sw, Wfw, A, Lam, q, lam, tc, Nz, Wdg, Wp = [x[:, i] for i in range(10)]
        Lam *= np.pi/180
        fac1 = (Wfw**0.0035)*((A/(np.cos(Lam)**2))**0.6)
        fac2 = (q**0.006)*(lam**0.04)*(((100*tc)/(np.cos(Lam)))**(-0.3))
        fac3 = (Nz*Wdg)**0.49
        return 0.036*(Sw**0.758)*fac1*fac2*fac3 + Sw*Wp
    def y_l1(x):
        Sw, Wfw, A, Lam, q, lam, tc, Nz, Wdg, Wp = [x[:, i] for i in range(10)]
        Lam *= np.pi/180
        fac1 = (Wfw**0.0035)*((A/(np.cos(Lam)**2))**0.6)
        fac2 = (q**0.006)*(lam**0.04)*(((100*tc)/(np.cos(Lam)))**(-0.3))
        fac3 = (Nz*Wdg)**0.49
        return 0.036*(Sw**0.758)*fac1*fac2*fac3 + 1*Wp
    def y_l2(x):
        Sw, Wfw, A, Lam, q, lam, tc, Nz, Wdg, Wp = [x[:, i] for i in range(10)]
        Lam *= np.pi/180
        fac1 = (Wfw**0.0035)*((A/(np.cos(Lam)**2))**0.6)
        fac2 = (q**0.006)*(lam**0.04)*(((100*tc)/(np.cos(Lam)))**(-0.3))
        fac3 = (Nz*Wdg)**0.49
        return 0.036*(Sw**0.8)*fac1*fac2*fac3 + 1*Wp
    def y_l3(x):
        Sw, Wfw, A, Lam, q, lam, tc, Nz, Wdg, Wp = [x[:, i] for i in range(10)]
        Lam *= np.pi/180
        fac1 = (Wfw**0.0035)*((A/(np.cos(Lam)**2))**0.6)
        fac2 = (q**0.006)*(lam**0.04)*(((100*tc)/(np.cos(Lam)))**(-0.3))
        fac3 = (Nz*Wdg)**0.49
        return 0.036*(Sw**0.9)*fac1*fac2*fac3 + 0*Wp
    y_list = [y_h, y_l1, y_l2, y_l3]
    y = lambda x, t: y_list[t](x)
    # Preallocate data arrays and indices
    # First, get the total number of input points for each set
    train_tot = sum(n_train)
    val_tot = sum(n_val)
    test_tot = sum(n_test)
    x_train = np.empty([train_tot, dx])
    x_val = np.empty([val_tot, dx])
    x_test = np.empty([test_tot, dx])
    y_train = np.empty([train_tot, dy])
    y_val = np.empty([val_tot, dy])
    y_test = np.empty([test_tot, dy])
    min_x = np.empty([dt[0], dnum]) # Set shape based on number of sources
    max_x = np.empty([dt[0], dnum]) # Set shape based on number of sources
    min_y = np.empty([dt[0], dy]) # Set shape based on number of sources
    max_y = np.empty([dt[0], dy]) # Set shape based on number of sources

    # Initialize the indices for training
    train_start = 0
    val_start = 0
    test_start = 0
    # Generate data
    for i in range(dt[0]):
        # Set end indices
        train_end = train_start + n_train[i]
        val_end = val_start + n_val[i]
        test_end = test_start + n_test[i]
        # Get data numbers
        n_train_temp = n_train[i]
        n_val_temp = n_val[i]
        n_test_temp = n_test[i]

        # Generate data

        x_train_temp = lhs(dnum, samples = n_train_temp) * RANGE + MIN
        y_train_temp = y(x_train_temp, i).reshape((n_train_temp, dy))

        x_val_temp = lhs(dnum, samples = n_val_temp) * RANGE + MIN
        y_val_temp = y(x_val_temp, i).reshape((n_val_temp, 1))

        x_test_temp = lhs(dnum, samples = n_test_temp) * RANGE + MIN
        y_test_temp = y(x_test_temp, i).reshape((n_test_temp, dy))

        # Add noise
        y_train_temp = y_train_temp + np.sqrt(var[i])*np.random.standard_normal(size=y_train_temp.shape)
        y_val_temp = y_val_temp + np.sqrt(var[i])*np.random.standard_normal(size=y_val_temp.shape)
        y_test_temp = y_test_temp + np.sqrt(var[i])*np.random.standard_normal(size=y_test_temp.shape)

        # Get the mins and maxs and store them
        min_x_temp = np.min(np.concatenate((x_train_temp[:, num_idx], x_val_temp[:, num_idx]), axis = 0), axis = 0)
        min_x[i, :] = min_x_temp
        max_x_temp = np.max(np.concatenate((x_train_temp[:, num_idx], x_val_temp[:, num_idx]), axis = 0), axis = 0)
        max_x[i, :] = max_x_temp

        min_y_temp = np.min(y_train_temp, axis = 0)
        min_y[i, :] = min_y_temp
        max_y_temp = np.max(y_train_temp, axis = 0)
        max_y[i, :] = max_y_temp
        range_y = max_y_temp - min_y_temp

        # Store the data
        x_train[train_start : train_end, 0:dnum] = x_train_temp
        x_train[train_start : train_end, dnum:dnum+source_idx[0]] = i*np.ones((np.shape(x_train_temp)[0], 1))
        y_train[train_start : train_end, :] = y_train_temp

        x_val[val_start : val_end, 0:dnum] = x_val_temp
        x_val[val_start : val_end, dnum:dnum+source_idx[0]] = i*np.ones((np.shape(x_val_temp)[0], 1))
        y_val[val_start : val_end, :] = y_val_temp

        x_test[test_start : test_end, 0:dnum] = x_test_temp
        x_test[test_start : test_end, dnum:dnum+source_idx[0]] = i*np.ones((np.shape(x_test_temp)[0], 1))
        y_test[test_start : test_end, :] = y_test_temp

        # Update indices
        train_start = train_end
        val_start = val_end
        test_start = test_end

    return (dx, dnum, dsource, dt, dy, num_idx, source_idx, min_x, max_x, min_y, max_y, x_train, y_train, x_val, y_val, x_test, y_test)

#### Mixed Data Generation Functions

def SinWave_v1_MX(n_train, n_val, n_test, var = 0):
    """
    Generates data for a simple 1-D mixed data problem with 3 categorical inputs.
    Input and output dimensions are 4 and 1 respectively, with the last 3 
    features being categorical.
    Data is scaled to the range [0, 1] based on mins and maxs of the dataset.
    Use the mins and maxs returned by this function to un-scale the data if 
    desired.
    Data is generated by sampling the input space (including categorical features)
    using sobol sequence.

    Inputs:
        n_train: An int that determines the total number of training samples
        n_val: An int that determines the total number of validation samples
        n_test: An int that determines the total number of test samples
        var: A float that determines the variance of the gaussian noise applied
            to the output
    
    Outputs:
        dx: The total input dimensionality. dx = int(4)
        dy: The output dimensionality. dy = int(1)
        dt: A touple whose length denotes the number of categorical variables and
            whose entries denote the number of levels for each. dt = (3, 3, 2)
        num_idx: An np array which lists the indices of the input that correspond
            to categorical variables. source_idx = (0,)
        source_idx: An np array which lists the indices of the input that correspond
            to categorical variables. source_idx = (1, 2, 3)
        tl: A touple of touples. Each entry of tl corresponds to a categorical
            variable and lists the values of that variable at each level.
            tl = ((2, 4, 8), (0.5, 1, 2), (pi/2, pi))
        min_x: The minimum of the sample range for the input. The categorical mins
            and maxs should not be used in scaling the data as these are used
            for sampling the levels.
        max_x: The maximum of the sample range for the input. The categorical mins
            and maxs should not be used in scaling the data as these are used
            for sampling the levels.
        min_y: The minimum of the sample range for the output.
        max_y: The maximum of the sample range for the output.
        x_train: The training inputs.
        y_train: The training outputs.
        x_val: The validation inputs.
        y_val: The validation outputs.
        x_test: The testing inputs.
        y_test: The testing outputs.
    """
    # Set parameters
    dx = 4
    dnum = 1
    dy = 1
    # dt is a list whose indices correspond to the categorical variable
    # and whose entries correspond to the number of levels for that variable
    dt = (3, 3, 2)
    num_idx = np.array([0])
    cat_idx = np.array([1, 2, 3])
    MIN = (-2*np.pi, 0, 0, 0)
    MAX = (2*np.pi, 3, 3, 2)
    RANGE = [MAX[i] - MIN[i] for i in range(dx)]
    tl = ((2, 4, 8), (0.5, 1, 2), (np.pi/2, np.pi))
    # Define y
    y = lambda x: x[:, 1]*np.sin(x[:, 2]*x[:, 0] + x[:, 3])
    # Preallocate data arrays and indices
    x_train = np.empty([n_train, dx])
    x_val = np.empty([n_val, dx])
    x_test = np.empty([n_test, dx])
    y_train = np.empty([n_train, dy])
    y_val = np.empty([n_val, dy])
    y_test = np.empty([n_test, dy])
    # Initialize the indices for training
    train_start = 0
    val_start = 0
    test_start = 0
    # Initialize function for transforming categorical input
    def t_to_tl(t, t_list):
        t_l = np.empty(t.shape)
        for (i, j), val in np.ndenumerate(t):
            t_l[i][j] = t_list[j][val]
        return t_l
    # Generate data
    x_train = lhs(dx, samples = n_train) * RANGE + MIN
    t_train_raw = np.floor(x_train[:, cat_idx]).astype(int)
    t_train = t_to_tl(np.floor(x_train[:, cat_idx]).astype(int), tl)
    x_train = np.concatenate((x_train[:, num_idx], t_train), axis = 1)
    y_train = y(x_train).reshape((n_train, dy))

    x_val = lhs(dx, samples = n_val) * RANGE + MIN
    t_val_raw = np.floor(x_val[:, cat_idx]).astype(int)
    t_val = t_to_tl(np.floor(x_val[:, cat_idx]).astype(int), tl)
    x_val = np.concatenate((x_val[:, num_idx], t_val), axis = 1)
    y_val = y(x_val).reshape((n_val, dy))

    x_test = lhs(dx, samples = n_test) * RANGE + MIN
    t_test_raw = np.floor(x_test[:, cat_idx]).astype(int)
    t_test = t_to_tl(np.floor(x_test[:, cat_idx]).astype(int), tl)
    x_test = np.concatenate((x_test[:, num_idx], t_test), axis = 1)
    y_test = y(x_test).reshape((n_test, dy))

    # Add noise
    y_train = y_train + np.sqrt(var)*np.random.standard_normal(size=y_train.shape)
    y_val = y_val + np.sqrt(var)*np.random.standard_normal(size=y_val.shape)
    y_test = y_test + np.sqrt(var)*np.random.standard_normal(size=y_test.shape)

    # Get the mins and maxes based on the training + validation data
    min_x = np.min(np.concatenate((x_train, x_val), axis=0), axis = 0)
    max_x = np.max(np.concatenate((x_train, x_val), axis=0), axis = 0)

    min_y = np.min(np.concatenate((y_train, y_val), axis=0), axis = 0)
    max_y = np.max(np.concatenate((y_train, y_val), axis=0), axis = 0)

    return (dx, dy, dnum, dt, num_idx, cat_idx, tl, min_x, max_x, min_y, max_y, x_train, t_train_raw, y_train, x_val, t_val_raw, y_val, x_test, t_test_raw, y_test)


def SinWave_v2_MX(n_train, n_val, n_test, var = 0):
    """
    Generates data for a simple 1-D mixed data problem with 3 categorical inputs.
    Input and output dimensions are 4 and 1 respectively, with the last 3 
    features being categorical.
    Data is scaled to the range [0, 1] based on mins and maxs of the dataset.
    Use the mins and maxs returned by this function to un-scale the data if 
    desired.
    Data is generated by sampling the input space (including categorical features)
    using sobol sequence.

    Inputs:
        n_train: An int that determines the total number of training samples
        n_val: An int that determines the total number of validation samples
        n_test: An int that determines the total number of test samples
        var: A float that determines the variance of the gaussian noise applied
            to the output
    
    Outputs:
        dx: The total input dimensionality. dx = int(4)
        dy: The output dimensionality. dy = int(1)
        dt: A touple whose length denotes the number of categorical variables and
            whose entries denote the number of levels for each. dt = (3, 3, 2)
        num_idx: An np array which lists the indices of the input that correspond
            to categorical variables. num_idx = (0,)
        cat_idx: An np array which lists the indices of the input that correspond
            to categorical variables. cat_idx = (1, 2, 3, 4)
        tl: A touple of touples. Each entry of tl corresponds to a categorical
            variable and lists the values of that variable at each level.
            tl = ((2, 4, 8), (0.5, 1, 2), (pi/2, pi), (0.5, 1))
        min_x: The minimum of the sample range for the input. The categorical mins
            and maxs should not be used in scaling the data as these are used
            for sampling the levels.
        max_x: The maximum of the sample range for the input. The categorical mins
            and maxs should not be used in scaling the data as these are used
            for sampling the levels.
        min_y: The minimum of the sample range for the output.
        max_y: The maximum of the sample range for the output.
        x_train: The training inputs.
        y_train: The training outputs.
        x_val: The validation inputs.
        y_val: The validation outputs.
        x_test: The testing inputs.
        y_test: The testing outputs.
    """
    # Set parameters
    dx = 5
    dnum = 1
    dy = 1
    # dt is a list whose indices correspond to the categorical variable
    # and whose entries correspond to the number of levels for that variable
    dt = (3, 3, 2, 2)
    num_idx = np.array([0])
    cat_idx = np.array([1, 2, 3, 4])
    MIN = (-2*np.pi, 0, 0, 0, 0)
    MAX = (2*np.pi, 3, 3, 2, 2)
    RANGE = [MAX[i] - MIN[i] for i in range(dx)]
    tl = ((2, 4, 8), (0.5, 1, 2), (np.pi/2, np.pi), (0.5, 1))
    # Define y
    y = lambda x: x[:, 4]*x[:, 1]*np.sin(x[:, 2]*x[:, 0] + x[:, 3])
    # Preallocate data arrays and indices
    x_train = np.empty([n_train, dx])
    x_val = np.empty([n_val, dx])
    x_test = np.empty([n_test, dx])
    y_train = np.empty([n_train, dy])
    y_val = np.empty([n_val, dy])
    y_test = np.empty([n_test, dy])
    # Initialize the indices for training
    train_start = 0
    val_start = 0
    test_start = 0
    # Initialize function for transforming categorical input
    def t_to_tl(t, t_list):
        t_l = np.empty(t.shape)
        for (i, j), val in np.ndenumerate(t):
            t_l[i][j] = t_list[j][val]
        return t_l
    # Generate data
    x_train = lhs(dx, samples = n_train) * RANGE + MIN
    t_train_raw = np.floor(x_train[:, cat_idx]).astype(int)
    t_train = t_to_tl(np.floor(x_train[:, cat_idx]).astype(int), tl)
    x_train = np.concatenate((x_train[:, num_idx], t_train), axis = 1)
    y_train = y(x_train).reshape((n_train, dy))

    x_val = lhs(dx, samples = n_val) * RANGE + MIN
    t_val_raw = np.floor(x_val[:, cat_idx]).astype(int)
    t_val = t_to_tl(np.floor(x_val[:, cat_idx]).astype(int), tl)
    x_val = np.concatenate((x_val[:, num_idx], t_val), axis = 1)
    y_val = y(x_val).reshape((n_val, dy))

    x_test = lhs(dx, samples = n_test) * RANGE + MIN
    t_test_raw = np.floor(x_test[:, cat_idx]).astype(int)
    t_test = t_to_tl(np.floor(x_test[:, cat_idx]).astype(int), tl)
    x_test = np.concatenate((x_test[:, num_idx], t_test), axis = 1)
    y_test = y(x_test).reshape((n_test, dy))

    # Add noise
    y_train = y_train + np.sqrt(var)*np.random.standard_normal(size=y_train.shape)
    y_val = y_val + np.sqrt(var)*np.random.standard_normal(size=y_val.shape)
    y_test = y_test + np.sqrt(var)*np.random.standard_normal(size=y_test.shape)

    # Get the mins and maxes based on the training + validation data
    min_x = np.min(np.concatenate((x_train, x_val), axis=0), axis = 0)
    max_x = np.max(np.concatenate((x_train, x_val), axis=0), axis = 0)

    min_y = np.min(np.concatenate((y_train, y_val), axis=0), axis = 0)
    max_y = np.max(np.concatenate((y_train, y_val), axis=0), axis = 0)

    # # Scale the data
    # y_train = (y_train-np.tile(min_y, (n_train, 1)))/np.tile(
    #     range_y, (n_train, 1))
    # x_train[:, num_idx] = (x_train[:, num_idx]-np.tile(min_x, (n_train, 1)))/np.tile(
    #     range_x, (n_train, 1))
    
    # y_val = (y_val-np.tile(min_y, (n_val, 1)))/np.tile(
    #     range_y, (n_val, 1))
    # x_val[:, num_idx] = (x_val[:, num_idx]-np.tile(min_x, (n_val, 1)))/np.tile(
    #     range_x, (n_val, 1))
    
    # y_test = (y_test-np.tile(min_y, (n_test, 1)))/np.tile(
    #     range_y, (n_test, 1))
    # x_test[:, num_idx] = (x_test[:, num_idx]-np.tile(min_x, (n_test, 1)))/np.tile(
    #     range_x, (n_test, 1))

    return (dx, dy, dnum, dt, num_idx, cat_idx, tl, min_x, max_x, min_y, max_y, x_train, t_train_raw, y_train, x_val, t_val_raw, y_val, x_test, t_test_raw, y_test)

#### Auxiliary functions

def scale_MX(x, y, num_idx, cat_idx, min_x, max_x, min_y, max_y):
    """
    For use in conjunction with mixed data generation.
    Scales both x and y to the range [0, 1]
    y is the output to scale, and x is the input for that output
        e.g. y_val and x_val
    x, dt, source_idx, min_y, max_y should be taken directly from the
        output of the data generation functions
    SS determines if the sources are scaled separately or jointly,
        with 0 indicating joint scaling.
    The output is the entire unscaled data array - you will still
        need to find specific indices for specific sources.
    """
    # Preallocate
    # Get the number of data points
    n_samp = x.shape[0]
    num_temp = x[:, num_idx]
    min_num = min_x[num_idx]
    max_num = max_x[num_idx]
    range_num = max_num - min_num
    t_temp = x[:, cat_idx]
    range_x = max_x - min_x
    range_y = max_y - min_y
    dy = y.shape[-1]
    # Scale
    num_temp = (num_temp - np.tile(min_num, (n_samp, 1)))/np.tile(range_num, (n_samp, 1))
    y_out = (y - np.tile(min_y, (n_samp, 1)))/np.tile(range_y, (n_samp, 1))
    # Get output
    x_out = np.concatenate((num_temp, t_temp), axis = 1)
    return x_out, y_out


def unscale_MX(x, y, num_idx, cat_idx, min_x, max_x, min_y, max_y):
    """
    For use in conjunction with mixed data generation.
    Unscales both x and y from the range [0, 1] to their original ranges.
    y is the output to scale, and x is the input for that output
        e.g. y_val and x_val
    x, dt, source_idx, min_y, max_y should be taken directly from the
        output of the data generation functions
    SS determines if the sources are scaled separately or jointly,
        with 0 indicating joint scaling.
    The output is the entire unscaled data array - you will still
        need to find specific indices for specific sources.
    """
    # Preallocate
    # Get the number of data points
    n_samp = x.shape[0]
    num_temp = x[:, num_idx]
    min_num = min_x[num_idx]
    max_num = max_x[num_idx]
    range_num = max_num - min_num
    t_temp = x[:, cat_idx]
    range_x = max_x - min_x
    range_y = max_y - min_y
    dy = y.shape[-1]
    # Scale
    num_temp = (num_temp * np.tile(range_num, (n_samp, 1))) + np.tile(min_num, (n_samp, 1))
    y_out = (y * np.tile(range_y, (n_samp, 1))) + np.tile(min_y, (n_samp, 1))
    # Get output
    x_out = np.concatenate((num_temp, t_temp), axis = 1)
    return x_out, y_out


def one_hot_MX(x, t, num_idx, cat_idx, dt):
    """
    One-hot encodes the data source for the input x.
    t_out will be a dummy matrix with a number of
    columns equal to the total number of categorical
    levels (NOT combinations).
    Note: This doesn't work the way I thought it would.
    You actually need the categoricals to be (0, 1, 2, etc)
    """
    # Preallocate
    x_out = x[:, num_idx]
    # For t_out, 
    t_out = np.empty((x.shape[0], np.sum(dt)))
    # One hot encode
    start_idx = 0
    for idx, level in enumerate(dt):
        # Update idx
        end_idx = start_idx + level
        # Assign one-hot encoding for each categorical variable
        t_out[:, start_idx:end_idx] = k.utils.to_categorical(t[:, idx], num_classes = level)
        # Update idx
        start_idx = end_idx
    return x_out, t_out


def t_to_tl(t, t_list):
    """
    For transforming categorical levels into their
    categorical values.
    """
    t_l = np.empty(t.shape)
    for (i, j), val in np.ndenumerate(t.astype(int)):
        t_l[i][j] = t_list[j][val]
    return t_l


def scale_MF(x, y, dnum, dsource, num_idx, source_idx, min_x, max_x, min_y, max_y, SS=0):
    """
    For use in conjunction with multi-fidelity data generation.
    Scales both x and y to the range [0, 1]
    y is the output to scale, and x is the input for that output
        e.g. y_val and x_val
    x, dt, source_idx, min_y, max_y should be taken directly from the
        output of the data generation functions
    SS determines if the sources are scaled separately or jointly,
        with 0 indicating joint scaling.
    The output is the entire unscaled data array - you will still
        need to find specific indices for specific sources.
    """
    # If we are not scaling separately, then only use the overall
    # max and mins
    if SS == 0:
        # Get the joint mins and maxs
        x_max_max = np.max(max_x, axis=0)
        x_min_min = np.min(min_x, axis=0)
        y_max_max = np.max(max_y, axis=0)
        y_min_min = np.min(min_y, axis=0)
        # Replace each row with the joint min/max
        max_x = np.tile(x_max_max, (dsource[0], 1))
        min_x = np.tile(x_min_min, (dsource[0], 1))
        max_y = np.tile(y_max_max, (dsource[0], 1))
        min_y = np.tile(y_min_min, (dsource[0], 1))
    # Preallocate
    num_temp = np.empty((x.shape[0], dnum))
    t_temp = x[:, source_idx]
    x_out = np.empty(x.shape)
    y_out = np.empty(y.shape)
    range_x = max_x - min_x
    range_y = max_y - min_y
    dy = y.shape[-1]
    idx_start = 0
    for i in range(dsource[0]):
        # Get the size of the data source
        n_samp = np.sum(x[:, source_idx]==i)
        # idx
        idx_end = idx_start + n_samp
        # Get data from data source
        x_temp = x[np.ix_(np.where(x[:, source_idx]==i)[0], num_idx)].reshape((n_samp, dnum))
        y_temp = y[np.where(x[:, source_idx]==i)[0], :].reshape((n_samp, dy))
        # Scale
        x_temp = (x_temp-np.tile(min_x[i, num_idx], (n_samp, 1)))/np.tile(range_x[i, num_idx], (n_samp, 1))
        y_temp = (y_temp-np.tile(min_y[i, :], (n_samp, 1)))/np.tile(range_y[i, :], (n_samp, 1))
        # Store
        num_temp[idx_start : idx_end, :] = x_temp
        y_out[idx_start : idx_end, :] = y_temp
        # Update idx
        idx_start = idx_end
    x_out = np.concatenate((num_temp, t_temp), axis = 1)
    return x_out, y_out


def unscale_MF(x, y, dnum, dsource, num_idx, source_idx, min_x, max_x, min_y, max_y, SS=0):
    """
    For use in conjunction with multi-fidelity data generation.
    Unscales both x and y from range [0, 1] to their original ranges.
    y is the output to scale, and x is the input for that output
        e.g. y_val and x_val
    x, dt, source_idx, min_y, max_y should be taken directly from the
        output of the data generation functions
    SS determines if the sources are scaled separately or jointly,
        with 0 indicating joint scaling.
    The output is the entire unscaled data array - you will still
        need to find specific indices for specific sources.
    """
    # If we are not scaling separately, then only use the overall
    # max and mins
    if SS == 0:
        # Get the joint mins and maxs
        x_max_max = np.max(max_x, axis=0)
        x_min_min = np.min(min_x, axis=0)
        y_max_max = np.max(max_y, axis=0)
        y_min_min = np.min(min_y, axis=0)
        # Replace each row with the joint min/max
        max_x = np.tile(x_max_max, (dsource[0], 1))
        min_x = np.tile(x_min_min, (dsource[0], 1))
        max_y = np.tile(y_max_max, (dsource[0], 1))
        min_y = np.tile(y_min_min, (dsource[0], 1))
    # Preallocate
    num_temp = np.empty((x.shape[0], dnum))
    t_temp = x[:, source_idx]
    x_out = np.empty(x.shape)
    y_out = np.empty(y.shape)
    range_x = max_x - min_x
    range_y = max_y - min_y
    dy = y.shape[-1]
    idx_start = 0
    for i in range(dsource[0]):
        # Get the size of the data source
        n_samp = np.sum(x[:, source_idx]==i)
        # idx
        idx_end = idx_start + n_samp
        # Get data from data source
        x_temp = x[np.ix_(np.where(x[:, source_idx]==i)[0], num_idx)].reshape((n_samp, dnum))
        y_temp = y[np.where(x[:, source_idx]==i)[0], :].reshape((n_samp, dy))
        # Unscale
        x_temp = x_temp*np.tile(range_x[i, num_idx], (n_samp, 1)) + np.tile(min_x[i, num_idx], (n_samp, 1))
        y_temp = y_temp*np.tile(range_y[i, :], (n_samp, 1)) + np.tile(min_y[i, :], (n_samp, 1))
        # Store
        num_temp[idx_start : idx_end, :] = x_temp
        y_out[idx_start : idx_end, :] = y_temp
        # Update idx
        idx_start = idx_end
    x_out = np.concatenate((num_temp, t_temp), axis = 1)
    return x_out, y_out


def one_hot_MF(x, num_idx, source_idx):
    """
    One-hot encodes the data source for the input x.
    """
    # Preallocate
    x_out = x[:, num_idx]
    # One hot encode
    t_out = k.utils.to_categorical(x[:, source_idx])
    return x_out, t_out


#### Data generation scripts

def MF_Data_Gen(problem = "Analytic 1", data_size = "small", noise = 0, scale_SS = 0, one_hot = 1):
    """
    
    """
    # Throw an error if the data size or problem is incorrect
    # if data_size != "small" & data_size != "large":
    #     print("Invalid data size \"{}\". Please use either \"large\" or \"small\" for data size.".format(data_size))
    #     return

    # Define the settings for each problem
    settings = {
    "Analytic 1": {
        "Function": Analytic_1_MF,
        "D_S": {
            "small": ((3, 20, 20, 20), (2, 10, 10, 10), (10000, 10000, 10000, 10000)),
            "large": ((50, 200, 200, 200), (25, 100, 100, 100), (10000, 10000, 10000, 10000))
        },
        "N_S": {
            0: (0, 0, 0, 0),
            1: (0.001, 0.001, 0.001, 0.001)
        }
    },
    "Borehole": {
        "Function": Borehole_MF,
        "D_S": {
            "small": ((10, 33, 33, 33), (5, 17, 17, 17), (10000, 10000, 10000, 10000)),
            "medium": ((10, 67, 67, 67), (5, 33, 33, 33), (10000, 10000, 10000, 10000)),
            "large": ((50, 200, 200, 200), (25, 100, 100, 100), (10000, 10000, 10000, 10000))
        },
        "N_S": {
            0: (0, 0, 0, 0),
            1: (6.25, 6.25, 6.25, 6.25)
        }
    },
    "Wing Weight": {
        "Function": WingWeight_MF,
        "D_S": {
            "small": ((10, 33, 33, 33), (5, 17, 17, 17), (10000, 10000, 10000, 10000)),
            "medium": ((10, 67, 67, 67), (5, 33, 33, 33), (10000, 10000, 10000, 10000)),
            "large": ((50, 200, 200, 200), (25, 100, 100, 100), (10000, 10000, 10000, 10000))
        },
        "N_S": {
            0: (0, 0, 0, 0),
            1: (25, 25, 25, 25)
        }
    }
                }
    # Get problem parameters
    ((n_train, n_val, n_test), var) = (settings[problem]["D_S"][data_size], settings[problem]["N_S"][noise])
    # Evaluate problem
    (dx, dnum, dsource, dt, dy, num_idx, source_idx, min_x, max_x, min_y, max_y, x_train, y_train, x_val, y_val, x_test, y_test) \
        = settings[problem]["Function"](n_train, n_val, n_test, var)
    # Scale data
    (x_train, y_train) = scale_MF(x_train, y_train, dnum, dsource, num_idx, source_idx, min_x, max_x, min_y, max_y, SS=scale_SS)
    (x_val, y_val) = scale_MF(x_val, y_val, dnum, dsource, num_idx, source_idx, min_x, max_x, min_y, max_y, SS=scale_SS)
    (x_test, y_test) = scale_MF(x_test, y_test, dnum, dsource, num_idx, source_idx, min_x, max_x, min_y, max_y, SS=scale_SS)
    # One-hot encode if required. Otherwise, split data based on source index.
    if one_hot:
        (x_train, t_train) = one_hot_MF(x_train, num_idx, source_idx)
        (x_val, t_val) = one_hot_MF(x_val, num_idx, source_idx)
        (x_test, t_test) = one_hot_MF(x_test, num_idx, source_idx)
    else:
        (x_train, t_train) = (x_train[:, num_idx], x_train[:, source_idx])
        (x_val, t_val) = (x_val[:, num_idx], x_val[:, source_idx])
        (x_test, t_test) = (x_test[:, num_idx], x_test[:, source_idx])
    return (dx, dnum, dsource, dt, dy, num_idx, source_idx, min_x, max_x, min_y, max_y, x_train, t_train, y_train, x_val, t_val, y_val, x_test, t_test, y_test)


def MX_Data_Gen(problem = "SinWave v2", data_size = "small", noise = 0, one_hot = 1):
    """
    
    """
    # Throw an error if the data size or problem is incorrect
    # if data_size != "small" & data_size != "large":
    #     print("Invalid data size \"{}\". Please use either \"large\" or \"small\" for data size.".format(data_size))
    #     return

    # Define the settings for each problem
    settings = {"SinWave v1": {
        "Function": SinWave_v1_MX,
        "D_S": {
            "small": (200, 100, 10000),
            "large": (500, 250, 10000),
            "huge": (5000, 2500, 10000),
        },
        "N_S": {
            0: 0,
            1: 0.1
        }
    },
    "SinWave v2": {
        "Function": SinWave_v2_MX,
        "D_S": {
            "small": (200, 100, 10000),
            "large": (500, 250, 10000),
            "huge": (5000, 2500, 10000),
        },
        "N_S": {
            0: 0,
            1: 0.1
        }
    }
                }
    # Get problem parameters
    ((n_train, n_val, n_test), var) = (settings[problem]["D_S"][data_size], settings[problem]["N_S"][noise])
    # Evaluate problem
    (dx, dy, dnum, dt, num_idx, cat_idx, tl, min_x, max_x, min_y, max_y, x_train, t_train_raw, y_train, x_val, t_val_raw, y_val, x_test, t_test_raw, y_test) \
        = settings[problem]["Function"](n_train, n_val, n_test, var)
    # Scale data
    (x_train, y_train) = scale_MX(x_train, y_train, num_idx, cat_idx, min_x, max_x, min_y, max_y)
    (x_val, y_val) = scale_MX(x_val, y_val, num_idx, cat_idx, min_x, max_x, min_y, max_y)
    (x_test, y_test) = scale_MX(x_test, y_test, num_idx, cat_idx, min_x, max_x, min_y, max_y)
    # One-hot encode if required. Otherwise, split data based on source index.
    if one_hot:
        (x_train, t_train) = one_hot_MX(x_train, t_train_raw, num_idx, cat_idx, dt)
        (x_val, t_val) = one_hot_MX(x_val, t_val_raw, num_idx, cat_idx, dt)
        (x_test, t_test) = one_hot_MX(x_test, t_test_raw, num_idx, cat_idx, dt)
    else:
        (x_train, t_train) = (x_train[:, num_idx], t_train_raw)
        (x_val, t_val) = (x_val[:, num_idx], t_val_raw)
        (x_test, t_test) = (x_test[:, num_idx], t_test_raw)
    return (dx, dy, dnum, dt, num_idx, cat_idx, tl, min_x, max_x, min_y, max_y, x_train, t_train, y_train, x_val, t_val, y_val, x_test, t_test, y_test)
    